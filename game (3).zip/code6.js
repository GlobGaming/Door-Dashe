gdjs.chaseCode = {};
gdjs.chaseCode.GDNewBBTextObjects1= [];
gdjs.chaseCode.GDNewBBTextObjects2= [];
gdjs.chaseCode.GDNewSpriteObjects1= [];
gdjs.chaseCode.GDNewSpriteObjects2= [];
gdjs.chaseCode.GDNewSprite2Objects1= [];
gdjs.chaseCode.GDNewSprite2Objects2= [];


gdjs.chaseCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.chaseCode.mapOfGDgdjs_9546chaseCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.chaseCode.GDNewSprite2Objects1});
gdjs.chaseCode.mapOfGDgdjs_9546chaseCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.chaseCode.GDNewSpriteObjects1});
gdjs.chaseCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "beyond.mp3", 1, true, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyReleased(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.chaseCode.GDNewSprite2Objects1);
{for(var i = 0, len = gdjs.chaseCode.GDNewSprite2Objects1.length ;i < len;++i) {
    gdjs.chaseCode.GDNewSprite2Objects1[i].setX(gdjs.chaseCode.GDNewSprite2Objects1[i].getX() - (20));
}
}
{ //Subevents
gdjs.chaseCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.doesSceneExist(runtimeScene, "Untitled scene");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.chaseCode.GDNewSprite2Objects1);
{for(var i = 0, len = gdjs.chaseCode.GDNewSprite2Objects1.length ;i < len;++i) {
    gdjs.chaseCode.GDNewSprite2Objects1[i].setX(gdjs.chaseCode.GDNewSprite2Objects1[i].getX() + (6));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.chaseCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.chaseCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chaseCode.mapOfGDgdjs_9546chaseCode_9546GDNewSprite2Objects1Objects, gdjs.chaseCode.mapOfGDgdjs_9546chaseCode_9546GDNewSpriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "die to runner", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "a");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "a") >= 20.5442346567;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "other thing", false);
}}

}


};

gdjs.chaseCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.chaseCode.GDNewBBTextObjects1.length = 0;
gdjs.chaseCode.GDNewBBTextObjects2.length = 0;
gdjs.chaseCode.GDNewSpriteObjects1.length = 0;
gdjs.chaseCode.GDNewSpriteObjects2.length = 0;
gdjs.chaseCode.GDNewSprite2Objects1.length = 0;
gdjs.chaseCode.GDNewSprite2Objects2.length = 0;

gdjs.chaseCode.eventsList1(runtimeScene);

return;

}

gdjs['chaseCode'] = gdjs.chaseCode;
