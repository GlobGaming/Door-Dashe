gdjs.CreditsCode = {};
gdjs.CreditsCode.GDNewBBTextObjects1= [];
gdjs.CreditsCode.GDNewBBTextObjects2= [];
gdjs.CreditsCode.GDNewTiledSprite2Objects1= [];
gdjs.CreditsCode.GDNewTiledSprite2Objects2= [];
gdjs.CreditsCode.GDMedievalButtonBeigeObjects1= [];
gdjs.CreditsCode.GDMedievalButtonBeigeObjects2= [];


gdjs.CreditsCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MedievalButtonBeige"), gdjs.CreditsCode.GDMedievalButtonBeigeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CreditsCode.GDMedievalButtonBeigeObjects1.length;i<l;++i) {
    if ( gdjs.CreditsCode.GDMedievalButtonBeigeObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.CreditsCode.GDMedievalButtonBeigeObjects1[k] = gdjs.CreditsCode.GDMedievalButtonBeigeObjects1[i];
        ++k;
    }
}
gdjs.CreditsCode.GDMedievalButtonBeigeObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "incognition.mp3", 1, false, 75, 1);
}}

}


};

gdjs.CreditsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CreditsCode.GDNewBBTextObjects1.length = 0;
gdjs.CreditsCode.GDNewBBTextObjects2.length = 0;
gdjs.CreditsCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.CreditsCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.CreditsCode.GDMedievalButtonBeigeObjects1.length = 0;
gdjs.CreditsCode.GDMedievalButtonBeigeObjects2.length = 0;

gdjs.CreditsCode.eventsList0(runtimeScene);

return;

}

gdjs['CreditsCode'] = gdjs.CreditsCode;
