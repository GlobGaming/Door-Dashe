gdjs.Untitled_32scene4Code = {};
gdjs.Untitled_32scene4Code.GDPlayerObjects1= [];
gdjs.Untitled_32scene4Code.GDPlayerObjects2= [];
gdjs.Untitled_32scene4Code.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32scene4Code.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32scene4Code.GDNewSprite2Objects1= [];
gdjs.Untitled_32scene4Code.GDNewSprite2Objects2= [];
gdjs.Untitled_32scene4Code.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32scene4Code.GDNewTiledSprite2Objects2= [];
gdjs.Untitled_32scene4Code.GDNewSprite3Objects1= [];
gdjs.Untitled_32scene4Code.GDNewSprite3Objects2= [];
gdjs.Untitled_32scene4Code.GDNewTextObjects1= [];
gdjs.Untitled_32scene4Code.GDNewTextObjects2= [];


gdjs.Untitled_32scene4Code.mapOfGDgdjs_9546Untitled_959532scene4Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32scene4Code.GDPlayerObjects1});
gdjs.Untitled_32scene4Code.mapOfGDgdjs_9546Untitled_959532scene4Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.Untitled_32scene4Code.GDNewSprite3Objects1});
gdjs.Untitled_32scene4Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.Untitled_32scene4Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32scene4Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32scene4Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32scene4Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32scene4Code.GDPlayerObjects1[k] = gdjs.Untitled_32scene4Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32scene4Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32scene4Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32scene4Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32scene4Code.GDPlayerObjects1[k] = gdjs.Untitled_32scene4Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32scene4Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene4Code.mapOfGDgdjs_9546Untitled_959532scene4Code_9546GDPlayerObjects1Objects, gdjs.Untitled_32scene4Code.mapOfGDgdjs_9546Untitled_959532scene4Code_9546GDNewSprite3Objects1Objects, false, runtimeScene, false);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32scene4Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32scene4Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene4Code.GDPlayerObjects1[i].flipX(true);
}
}{for(var i = 0, len = gdjs.Untitled_32scene4Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene4Code.GDPlayerObjects1[i].setAnimation(2);
}
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene5");
}}

}


};

gdjs.Untitled_32scene4Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32scene4Code.GDPlayerObjects1.length = 0;
gdjs.Untitled_32scene4Code.GDPlayerObjects2.length = 0;
gdjs.Untitled_32scene4Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32scene4Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32scene4Code.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32scene4Code.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32scene4Code.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32scene4Code.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32scene4Code.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32scene4Code.GDNewSprite3Objects2.length = 0;
gdjs.Untitled_32scene4Code.GDNewTextObjects1.length = 0;
gdjs.Untitled_32scene4Code.GDNewTextObjects2.length = 0;

gdjs.Untitled_32scene4Code.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32scene4Code'] = gdjs.Untitled_32scene4Code;
