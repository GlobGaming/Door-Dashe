gdjs.The_32TRUE_32finaleCode = {};
gdjs.The_32TRUE_32finaleCode.GDNewSpriteObjects1= [];
gdjs.The_32TRUE_32finaleCode.GDNewSpriteObjects2= [];
gdjs.The_32TRUE_32finaleCode.GDCopperRedBarObjects1= [];
gdjs.The_32TRUE_32finaleCode.GDCopperRedBarObjects2= [];
gdjs.The_32TRUE_32finaleCode.GDBlueFlatBarObjects1= [];
gdjs.The_32TRUE_32finaleCode.GDBlueFlatBarObjects2= [];
gdjs.The_32TRUE_32finaleCode.GDNewSprite2Objects1= [];
gdjs.The_32TRUE_32finaleCode.GDNewSprite2Objects2= [];
gdjs.The_32TRUE_32finaleCode.GDNewBBTextObjects1= [];
gdjs.The_32TRUE_32finaleCode.GDNewBBTextObjects2= [];
gdjs.The_32TRUE_32finaleCode.GDNewSprite3Objects1= [];
gdjs.The_32TRUE_32finaleCode.GDNewSprite3Objects2= [];
gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1= [];
gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects2= [];
gdjs.The_32TRUE_32finaleCode.GDNewTiledSprite2Objects1= [];
gdjs.The_32TRUE_32finaleCode.GDNewTiledSprite2Objects2= [];
gdjs.The_32TRUE_32finaleCode.GDNewSprite4Objects1= [];
gdjs.The_32TRUE_32finaleCode.GDNewSprite4Objects2= [];


gdjs.The_32TRUE_32finaleCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("Confidence").add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Confidence")) == 10;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText2"), gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1);
{for(var i = 0, len = gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1.length ;i < len;++i) {
    gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1[i].setBBText("You got this!");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Confidence")) == 20;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText2"), gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1);
{for(var i = 0, len = gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1.length ;i < len;++i) {
    gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1[i].setBBText("You can do it!");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Confidence")) == 30;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText2"), gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1);
{for(var i = 0, len = gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1.length ;i < len;++i) {
    gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1[i].setBBText(" I believe in you! ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Confidence")) == 40;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText2"), gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1);
{for(var i = 0, len = gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1.length ;i < len;++i) {
    gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1[i].setBBText("Keep trying!");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Confidence")) == 50;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText2"), gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1);
{for(var i = 0, len = gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1.length ;i < len;++i) {
    gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1[i].setBBText("You have the power to do this!");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ConfidencialTime");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ConfidencialTime") >= 20;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Confidence")) > 50;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "The End: GOod ending", false);
}{runtimeScene.getGame().getVariables().get("confidenceglobal").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Confidence")));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ConfidencialTime") >= 20;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Confidence")) <= 50;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "The End: Bad ending", false);
}{runtimeScene.getGame().getVariables().get("confidenceglobal").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Confidence")));
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.The_32TRUE_32finaleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.The_32TRUE_32finaleCode.GDNewSpriteObjects1.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewSpriteObjects2.length = 0;
gdjs.The_32TRUE_32finaleCode.GDCopperRedBarObjects1.length = 0;
gdjs.The_32TRUE_32finaleCode.GDCopperRedBarObjects2.length = 0;
gdjs.The_32TRUE_32finaleCode.GDBlueFlatBarObjects1.length = 0;
gdjs.The_32TRUE_32finaleCode.GDBlueFlatBarObjects2.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewSprite2Objects1.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewSprite2Objects2.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewBBTextObjects1.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewBBTextObjects2.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewSprite3Objects1.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewSprite3Objects2.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects1.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewBBText2Objects2.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewSprite4Objects1.length = 0;
gdjs.The_32TRUE_32finaleCode.GDNewSprite4Objects2.length = 0;

gdjs.The_32TRUE_32finaleCode.eventsList0(runtimeScene);

return;

}

gdjs['The_32TRUE_32finaleCode'] = gdjs.The_32TRUE_32finaleCode;
