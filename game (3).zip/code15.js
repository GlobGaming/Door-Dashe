gdjs.good_32job_46_46Code = {};
gdjs.good_32job_46_46Code.GDNewBBTextObjects1= [];
gdjs.good_32job_46_46Code.GDNewBBTextObjects2= [];


gdjs.good_32job_46_46Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("dialouge").add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("dialouge")) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.good_32job_46_46Code.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.good_32job_46_46Code.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.good_32job_46_46Code.GDNewBBTextObjects1[i].setBBText("I'm really proud of you, with all my heart.");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("dialouge")) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.good_32job_46_46Code.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.good_32job_46_46Code.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.good_32job_46_46Code.GDNewBBTextObjects1[i].setBBText("But now, your adventure has reached an end.");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("dialouge")) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.good_32job_46_46Code.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.good_32job_46_46Code.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.good_32job_46_46Code.GDNewBBTextObjects1[i].setBBText("I really hope to see you in the future...");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("dialouge")) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.good_32job_46_46Code.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.good_32job_46_46Code.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.good_32job_46_46Code.GDNewBBTextObjects1[i].setBBText("Wow..congrats on + ToString(GlobalVariable(confidenceglobal)) + confidence boosted on him..you really are a great hero..");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("dialouge")) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.good_32job_46_46Code.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.good_32job_46_46Code.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.good_32job_46_46Code.GDNewBBTextObjects1[i].setBBText("Good bye...");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("dialouge")) == 6;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene");
}{runtimeScene.getGame().getVariables().get("WIns").add(1);
}}

}


};

gdjs.good_32job_46_46Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.good_32job_46_46Code.GDNewBBTextObjects1.length = 0;
gdjs.good_32job_46_46Code.GDNewBBTextObjects2.length = 0;

gdjs.good_32job_46_46Code.eventsList0(runtimeScene);

return;

}

gdjs['good_32job_46_46Code'] = gdjs.good_32job_46_46Code;
