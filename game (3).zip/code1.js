gdjs.Untitled_32scene2Code = {};
gdjs.Untitled_32scene2Code.GDNewSpriteObjects1= [];
gdjs.Untitled_32scene2Code.GDNewSpriteObjects2= [];
gdjs.Untitled_32scene2Code.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32scene2Code.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32scene2Code.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32scene2Code.GDNewTiledSprite2Objects2= [];
gdjs.Untitled_32scene2Code.GDNewSprite2Objects1= [];
gdjs.Untitled_32scene2Code.GDNewSprite2Objects2= [];
gdjs.Untitled_32scene2Code.GDNewTextObjects1= [];
gdjs.Untitled_32scene2Code.GDNewTextObjects2= [];
gdjs.Untitled_32scene2Code.GDNewSprite3Objects1= [];
gdjs.Untitled_32scene2Code.GDNewSprite3Objects2= [];
gdjs.Untitled_32scene2Code.GDNewSprite5Objects1= [];
gdjs.Untitled_32scene2Code.GDNewSprite5Objects2= [];
gdjs.Untitled_32scene2Code.GDNewSprite4Objects1= [];
gdjs.Untitled_32scene2Code.GDNewSprite4Objects2= [];
gdjs.Untitled_32scene2Code.GDPlayerObjects1= [];
gdjs.Untitled_32scene2Code.GDPlayerObjects2= [];
gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects1= [];
gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects2= [];


gdjs.Untitled_32scene2Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "instincts.mp3", 1, true, 75, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MedievalButtonBeige"), gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects1[k] = gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "First Room Cutscene", false);
}}

}


};

gdjs.Untitled_32scene2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32scene2Code.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewTextObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewTextObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewSprite3Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewSprite5Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewSprite5Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewSprite4Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewSprite4Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDPlayerObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDPlayerObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDMedievalButtonBeigeObjects2.length = 0;

gdjs.Untitled_32scene2Code.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32scene2Code'] = gdjs.Untitled_32scene2Code;
