gdjs.First_32Room_32CutsceneCode = {};
gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects1= [];
gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects2= [];
gdjs.First_32Room_32CutsceneCode.GDNewTiledSpriteObjects1= [];
gdjs.First_32Room_32CutsceneCode.GDNewTiledSpriteObjects2= [];


gdjs.First_32Room_32CutsceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects1[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects1[k] = gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene4", false);
}}

}


};

gdjs.First_32Room_32CutsceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects1.length = 0;
gdjs.First_32Room_32CutsceneCode.GDNewSpriteObjects2.length = 0;
gdjs.First_32Room_32CutsceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.First_32Room_32CutsceneCode.GDNewTiledSpriteObjects2.length = 0;

gdjs.First_32Room_32CutsceneCode.eventsList0(runtimeScene);

return;

}

gdjs['First_32Room_32CutsceneCode'] = gdjs.First_32Room_32CutsceneCode;
