gdjs.The_32FInale_46_46_46Code = {};
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeigeObjects1= [];
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeigeObjects2= [];
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects1= [];
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects2= [];
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects1= [];
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects2= [];
gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1= [];
gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects2= [];
gdjs.The_32FInale_46_46_46Code.GDNewSprite2Objects1= [];
gdjs.The_32FInale_46_46_46Code.GDNewSprite2Objects2= [];
gdjs.The_32FInale_46_46_46Code.GDNewTiledSprite2Objects1= [];
gdjs.The_32FInale_46_46_46Code.GDNewTiledSprite2Objects2= [];
gdjs.The_32FInale_46_46_46Code.GDNewSprite3Objects1= [];
gdjs.The_32FInale_46_46_46Code.GDNewSprite3Objects2= [];


gdjs.The_32FInale_46_46_46Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1[i].setX(gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1[i].getX() + (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MedievalButtonBeige3"), gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects1.length;i<l;++i) {
    if ( gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects1[k] = gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects1[i];
        ++k;
    }
}
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1[i].setX(gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1[i].getX() - (30));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MedievalButtonBeige2"), gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects1.length;i<l;++i) {
    if ( gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects1[k] = gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects1[i];
        ++k;
    }
}
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "attackcooldown") >= 20;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "attackcooldown");
}{for(var i = 0, len = gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1[i].setX(gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1[i].getX() - (100));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "seektime") >= 40;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "The TRUE finale");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "seektime");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "attackcooldown");
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "exponential.mp3", 1, true, 75, 1);
}}

}


};

gdjs.The_32FInale_46_46_46Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeigeObjects1.length = 0;
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeigeObjects2.length = 0;
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects1.length = 0;
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige2Objects2.length = 0;
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects1.length = 0;
gdjs.The_32FInale_46_46_46Code.GDMedievalButtonBeige3Objects2.length = 0;
gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects1.length = 0;
gdjs.The_32FInale_46_46_46Code.GDNewSpriteObjects2.length = 0;
gdjs.The_32FInale_46_46_46Code.GDNewSprite2Objects1.length = 0;
gdjs.The_32FInale_46_46_46Code.GDNewSprite2Objects2.length = 0;
gdjs.The_32FInale_46_46_46Code.GDNewTiledSprite2Objects1.length = 0;
gdjs.The_32FInale_46_46_46Code.GDNewTiledSprite2Objects2.length = 0;
gdjs.The_32FInale_46_46_46Code.GDNewSprite3Objects1.length = 0;
gdjs.The_32FInale_46_46_46Code.GDNewSprite3Objects2.length = 0;

gdjs.The_32FInale_46_46_46Code.eventsList0(runtimeScene);

return;

}

gdjs['The_32FInale_46_46_46Code'] = gdjs.The_32FInale_46_46_46Code;
