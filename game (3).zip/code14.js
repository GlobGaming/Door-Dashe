gdjs.The_32End_58_32Bad_32endingCode = {};


gdjs.The_32End_58_32Bad_32endingCode.eventsList0 = function(runtimeScene) {

};

gdjs.The_32End_58_32Bad_32endingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.The_32End_58_32Bad_32endingCode.eventsList0(runtimeScene);

return;

}

gdjs['The_32End_58_32Bad_32endingCode'] = gdjs.The_32End_58_32Bad_32endingCode;
